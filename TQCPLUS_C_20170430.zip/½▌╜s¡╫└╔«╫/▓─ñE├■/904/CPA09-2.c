#include <stdio.h>

int main() {

    FILE *file = fopen("score.dat", "r");
    
    int score = 0;
    char name[32];
    
    while (score >= 0) {
        fscanf(file, "%s", name);
        fscanf(file, "%d", &score);
        
        if (score >= 0) {
            printf("%s��C�y�����ƬO%d\n", name, score);
        }
    }

    fclose(file);
    
    system("pause");
    
    return 0;
}
