#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {

    int i, j, rnd;
    
    srand(time(NULL));
    
    for (i = 0; i < 10; i++) {
        for (j = 0; j < 10; j++) {
        
            rnd = rand() % 1000 + 1;
                
            printf("%4d ", rnd);
        }
        putchar('\n');
    }

    system("pause");
    
    return 0;
}
