#include <stdio.h>
#include <stdlib.h>

int main()
{
    char string[20];
    double output;

    printf("�п�J�@�Ʀr���r��: ");
    scanf("%s", string);
    
    output=atoi(string);

    printf("%s�ഫ�᪺��Ƭ�%.2f\n", string, output);

    system("PAUSE");

    return 0;
} 
