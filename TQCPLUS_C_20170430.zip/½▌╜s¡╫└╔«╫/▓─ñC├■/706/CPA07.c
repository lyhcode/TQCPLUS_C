#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main () 
{
    int x, y;
    double result;

    printf("�п�Jx, y����: ");
    scanf("%d %d", &x, &y);
    
    result=exp(5)*sqrt(pow(x, y)+log(100))/pow(x, 2)*pow(y, 3);

    printf("result=%f\n", result);

    system("PAUSE");

    return 0;
}
