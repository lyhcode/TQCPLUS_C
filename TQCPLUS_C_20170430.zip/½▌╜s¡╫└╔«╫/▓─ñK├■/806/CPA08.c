#include <stdio.h>

void printStar(int);
void multiply(int, int);

int main() {
    
    int n, s;
    
    printf("�п�J�z�n�X���X�����k��(�̦h10):");
    scanf("%d", &n);
    
    printf("�п�J�z�n�h�֭ӬP�P(*):");
    scanf("%d", &s);
    
    printStar(s);
    
    multiply(n, s);
    
    system("pause");
    
    return 0;
}

void multiply(int n, int s) {
     int i, j;
     
     for (i = 1; i <= n; i++) {
         for (j = 1; j <= n; j++) {
             printf("%2d*%2d=%2d ", i, j, i * j);
         }
         putchar('\n');
         printStar(s);
     }
}

void printStar(int n) {
    int i;
    
    for (i = 0; i < n; i++) {
        putchar('*');
    }
    
    putchar('\n');
}
