#include <stdio.h>

float average(float[], int);

int main() {
    
    int i;
    //float data[6] = {1.258, 2.3369, 5.54, 70.1, 66.254, 13.2154};    
    float data[6] = {0};

    for (i = 0; i < 6; i++) {
        printf("�п�J��%d�ӯB�I��:", i + 1);
        scanf("%f", &data[i]);
    }
    
    printf("�z��J���}�C�Ȧp�U\n");
    
    for (i = 0; i < 6; i++) {
        printf("data[%d]:%.3f\n", i, data[i]);
    }
  
    printf("\n����:%.4f\n", average(data, 6));
    
    system("pause");
    
    return 0;
}

float average(float arr2[], int n) {
    int i;
    float total = 0;
    for (i = 0; i < n; i++) {
        total += arr2[i];
    }
    return total/n;
}
