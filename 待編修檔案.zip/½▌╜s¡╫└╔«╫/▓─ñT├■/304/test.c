#include <stdio.h>

int main() {
    int arr[3] = {1, 2, 3};

    printf("%d\n", arr);        // addr of arr
    
    printf("%d\n", arr[1]);     // 2
    
    printf("%d\n", arr[3]);     // ??? 
    
    printf("%d\n", arr + 1);    // addr of second elem in arr
    
    printf("%d\n", *(arr + 1)); // 2
    
    printf("%d\n", arr + 2);
    
    getch();
}


//[int]  [int]  [int]

//arr    arr+1  arr+2
