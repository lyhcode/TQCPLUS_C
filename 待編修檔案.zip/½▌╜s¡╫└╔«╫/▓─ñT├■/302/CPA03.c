#include <stdio.h>
#include <stdlib.h>

int main()
{
	int score = 0, final = 0;
	
	printf("�п�J�z������: ");
	scanf("%d", &score);
	
	final = adjust(score);
 
	printf("�վ�᪺����: %d", final);
	
    system("PAUSE");
	
    return 0;
}

int adjust(int score)
{
    if (score >= 60) {
		return score + 5;
    }

    return score + 10;
}
