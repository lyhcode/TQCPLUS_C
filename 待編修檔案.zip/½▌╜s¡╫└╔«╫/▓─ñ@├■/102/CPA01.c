#include <stdio.h>
#include <stdlib.h>

int main() 
{	
	double a, b;
	double total;
	
	//input
	printf("�п�J��ӯB�I��:");
	scanf("%lf %lf", &a, &b);
	
	//process
    total = a + b;
    
    //output
	printf("total=%lf", total);
	
	system("PAUSE");
	
	return 0;
}
